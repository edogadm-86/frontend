export { SplashScreen } from "./SplashScreen";
